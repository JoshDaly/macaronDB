# macaronDB

## Overview

## Installation

Should be as simple as

    pip install macaronDB

## Example usage

## Help

If you experience any problems using macaronDB, open an [issue](https://github.com/minillinim/macaronDB/issues) on GitHub and tell us about it.

## Licence and referencing

Project home page, info on the source tree, documentation, issues and how to contribute, see http://github.com/minillinim/macaronDB

This software is currently unpublished

## Copyright

Copyright (c) 2014 Michael Imelfort. See LICENSE.txt for further details.
